#define SC "SCX_"
#define CPU_CFG "CPU"
#define CFE_SC 66
#define CPU1_IP "192.168.1.4"
#define CPU2_IP "192.168.1.6"
#define CPU3_IP "192.168.1.8"
#define MISSION "CFE"
local RAM_0="/ram/"
local numCPUs = 3
