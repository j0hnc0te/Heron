
The file "dox_templates.xml" contains some 
eclipse templates for some of the doxygen 
comment blocks that were specified in the 
CFS development standards document.

For guidance on how to import and use these, 
pull up the help contents in Eclipse and 
search on "Templates". See the section on 
"Importing and exporting code templates" and 
then the section on "Creating and editing 
code templates"

Once imported, they all begin with "dox"
Type "dox" then hit "Ctrl-Space" and select 
the one you want from the list. Feel free 
to edit or tweak these to your preferences.

These were created under the Windows CDT 
v3.3.0
