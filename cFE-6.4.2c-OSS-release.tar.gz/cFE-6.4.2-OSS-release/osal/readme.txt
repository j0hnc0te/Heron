Obtain the OS Abstraction layer (osal) at:
sourceforge.net/projects/osal
or 
github.com/nasa.osal

The current version as of October 2014 is 4.1.1.


