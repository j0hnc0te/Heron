void MODULE_NAME(void)
{
  volatile int i;
  i = 1; 
  return; 
}


